import Foundation
import FirebaseFirestore

class TimeCapsuleViewController {
}
